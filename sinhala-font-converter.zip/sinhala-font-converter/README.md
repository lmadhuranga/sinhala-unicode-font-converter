# sinhala-unicode-font-converter
This will convert to unicode as well as sinhala font { fm group and ml }
